//
//  ContactEmailTableViewCell.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/15/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class ContactEmailTableViewCell: BaseContactDetailTableViewCell {

    @IBOutlet var typeLabel:UILabel?
    @IBOutlet var emailLabel:UILabel?

    override func setupContact(contact:Recipient, rowIndex:Int)
    {
        if let emails = contact.emails
        {
            let type = emails.keys.array[rowIndex]
            if let email = emails[type]
            {
                self.typeLabel?.text = type
                self.emailLabel?.text = email
            }
            
            if (rowIndex == emails.count-1)
            {
                self.lineView?.hidden = false
            }
            else
            {
                self.lineView?.hidden = true
            }
        }
    }


}
