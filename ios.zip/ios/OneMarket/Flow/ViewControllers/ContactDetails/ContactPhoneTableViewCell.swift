//
//  PhoneTableViewCell.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/15/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class ContactPhoneTableViewCell: BaseContactDetailTableViewCell {

    @IBOutlet var typeLabel:UILabel?
    @IBOutlet var phoneLabel:UILabel?
    @IBOutlet var chatImageView:UIImageView?
    
    override func setupContact(contact:Recipient, rowIndex:Int)
    {
        if let phones = contact.phones
        {
            let type = phones.keys.array[rowIndex]
            self.chatImageView?.hidden = true
            if (type == "mobile" || type == "iPhone")
            {
                self.chatImageView?.hidden = false
            }
            if let phone = phones[type]
            {
                self.typeLabel?.text = type
                self.phoneLabel?.text = phone
            }
            if (rowIndex == phones.count-1)
            {
                self.lineView?.hidden = false
            }
            else
            {
                self.lineView?.hidden = true
            }
        }
    }

}
