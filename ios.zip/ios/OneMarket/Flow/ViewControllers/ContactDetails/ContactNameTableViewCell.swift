//
//  NameTableViewCell.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/15/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class ContactNameTableViewCell: BaseContactDetailTableViewCell {

    @IBOutlet var nameLabel:UILabel?
    @IBOutlet var companyLabel:UILabel?
    
    func setupName(name:String, companyName:String?)
    {
        self.nameLabel?.text = name
        self.companyLabel?.text = companyName
    }
    
    override func setupContact(contact:Recipient, rowIndex:Int)
    {
        self.nameLabel?.text = contact.displayName
        self.companyLabel?.text = contact.companyName
    }

}
