//
//  NotesTableViewCell.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/15/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class ContactNotesTableViewCell: UITableViewCell {

    @IBOutlet var notesTextView:UITextView?

}
