//
//  ExternalAppInvokingTableViewCell.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/15/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class ContactGeneralTableViewCell: UITableViewCell {

    @IBOutlet var label:UILabel?
    
    func setupLabel(labelValue:String)
    {
        self.label?.text = labelValue
    }
    
}
