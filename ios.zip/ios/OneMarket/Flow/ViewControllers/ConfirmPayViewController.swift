//
//  ConfirmSendMoneyViewController.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/4/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class ConfirmPayViewController: SendRequestMoneyViewController
{

    @IBOutlet var amountValueLabel:UILabel?
    @IBOutlet var memoValueLabel:UILabel?
    @IBOutlet var confirmButton:UIButton?
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        amountValueLabel?.text = self.selectedRecipient?.amount
        memoValueLabel?.text = self.selectedRecipient?.memo
        self.confirmButton?.setStyle("PrimaryButton")
    }

    @IBAction func confirmToPayButtonTouched(sender:AnyObject?)
    {
        self.authenticateUser()
    }
}
    



