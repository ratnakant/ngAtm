//
//  SignInViewController.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/23/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class SignInViewController: BaseFlowViewController
{
    @IBOutlet var userIdTextField: UITextField?
    @IBOutlet var userIdView: UIView?
    @IBOutlet var loginButton: UIButton?

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Sign In"
        self.userIdView?.layer.borderColor = UIColor.colorWithHexString("272757", alpha: 0.6)?.CGColor
        self.userIdView?.layer.borderWidth = 1.0
        self.loginButton?.setStyle("PrimaryButton")
    }
    
    @IBAction func loginButtonTouched(sender:AnyObject?)
    {
    }

}
