//
//  ContactsViewController.swift
//  OneMarket
//
//  Created by Vijay Jain on 5/27/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit
import AddressBook
import AddressBookUI

class ContactsViewController: BaseFlowViewController, ABPeoplePickerNavigationControllerDelegate
{
    @IBOutlet var sendRequestButtonsView: UIView?
    var contactManager:ContactManager = ContactManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.sendRequestButtonsView?.hidden = true
        if self.selectedRecipient != nil
        {
            self.sendRequestButtonsView?.hidden = false
        }
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
        if (segue.identifier == "SegueToAddressBook")
        {
            if let peoplePickerNavigationController = segue.destinationViewController as? ABPeoplePickerNavigationController
            {
                peoplePickerNavigationController.peoplePickerDelegate = self
            }
        }
    }
    
    func peoplePickerNavigationController(peoplePicker: ABPeoplePickerNavigationController!,
        shouldContinueAfterSelectingPerson person: ABRecord!,
        property: ABPropertyID,
        identifier: ABMultiValueIdentifier) -> Bool
    {
        return true
    }
    
    func peoplePickerNavigationController(peoplePicker: ABPeoplePickerNavigationController!, didSelectPerson person: ABRecord!)
    {
        self.selectedRecipient = Recipient();
        if let recipient = self.selectedRecipient
        {
            self.contactManager.setupContact(recipient, fromAddressBookRecord: person)
        }
            
        if let contactDetailsViewController = self.storyboard?.instantiateViewControllerWithIdentifier("ContactDetailsViewController") as? ContactDetailsViewController
        {
            contactDetailsViewController.selectedRecipient = self.selectedRecipient
            self.navigationController?.pushViewController(contactDetailsViewController, animated: true)
        }
    }
    
    func peoplePickerNavigationController(peoplePicker: ABPeoplePickerNavigationController!, didSelectPerson person: ABRecord!, property: ABPropertyID, identifier: ABMultiValueIdentifier)
    {
        
    }

    func peoplePickerNavigationControllerDidCancel(peoplePicker: ABPeoplePickerNavigationController!)
    {
        self.selectedRecipient = nil
    }
}
