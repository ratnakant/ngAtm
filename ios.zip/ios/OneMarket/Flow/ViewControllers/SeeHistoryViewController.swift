//
//  SeeHistoryViewController.swift
//  OneMarket
//
//  Created by Vijay Jain on 5/29/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class SeeHistoryViewController: BaseFlowViewController, UITableViewDelegate, UITableViewDataSource
{
    var transactions:[Transaction]?
    let TransactionCellName = "TransactionCell"
    let NoTransactionCellName = "NoTransactionCell"
    
    var getTransactionsService:GetTransactionsService?
    
    @IBOutlet var nameLabel: UILabel?
    @IBOutlet var transactionTableView: UITableView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "See History"
        if let person = self.selectedRecipient
        {
            self.nameLabel?.text = person.displayName
        }
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.downloadTransactionsHistory()
    }
    
    func downloadTransactionsHistory()
    {
        self.getTransactionsService = GetTransactionsService()
        if let selectedRecipient = self.selectedRecipient
        {
            self.getTransactionsService?.getTransactions(selectedRecipient, errorHandler: { (error:NSError?) -> () in
                self.displayError(error)
                },  completionHandler:{ () -> () in
                    
                    dispatch_async(dispatch_get_main_queue()) {
                        self.transactions = self.getTransactionsService?.transactions
                        self.transactionTableView?.reloadData()
                    }
            })
        }
    }

    @IBAction func cancelButtonTouched(sender:AnyObject?)
    {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        var rowsCount = 0
        if let transactions = self.transactions
        {
            rowsCount = transactions.count
        }
        return rowsCount
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        var returnedCell: UITableViewCell? = nil
        
        if let transactions = self.transactions
        {
            if transactions.count > 0 {
                
                let cell = tableView.dequeueReusableCellWithIdentifier(self.TransactionCellName, forIndexPath: indexPath) as? TransactionTableViewCell
                
                if let transaction = self.transactions?[indexPath.row]  {
                    cell?.setupTransaction(transaction)
                }
                
                cell?.selectionStyle = UITableViewCellSelectionStyle.None
                returnedCell = cell
                
            } else {
                
                let cell = tableView.dequeueReusableCellWithIdentifier(self.NoTransactionCellName, forIndexPath: indexPath) as? UITableViewCell
                cell?.selectionStyle = UITableViewCellSelectionStyle.None
                cell?.textLabel?.text = "No transaction found"
                returnedCell = cell
            }
        }
        
        return returnedCell!
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 60.0
    }
}
