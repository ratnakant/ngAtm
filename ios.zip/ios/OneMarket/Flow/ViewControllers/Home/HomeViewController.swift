//
//  HomeViewController.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/22/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class HomeViewController: BaseFlowViewController {

    let AllContactsTableViewCellName = "AllContactsTableViewCell"
    let NearbyDevicesTableViewCellName = "NearbyDevicesTableViewCell"

    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.title = "Home"
    }

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        var rowsCount = 2
        return rowsCount
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        var returnedCell: UITableViewCell? = nil
        
            if indexPath.row == 0 {
                
                let cell = tableView.dequeueReusableCellWithIdentifier(self.AllContactsTableViewCellName, forIndexPath: indexPath) as? UITableViewCell
                
                cell?.selectionStyle = UITableViewCellSelectionStyle.None
                returnedCell = cell
                
            } else {
                
                let cell = tableView.dequeueReusableCellWithIdentifier(self.NearbyDevicesTableViewCellName, forIndexPath: indexPath) as? UITableViewCell
                cell?.selectionStyle = UITableViewCellSelectionStyle.None
                returnedCell = cell
            }
        
        return returnedCell!
    }

    @IBAction func settingsButtonTouched(sender:AnyObject?)
    {
        let settingsStoryboard = UIStoryboard(name:"Settings", bundle: nil)
        if let settingsNaivigationController = settingsStoryboard.instantiateViewControllerWithIdentifier("SettingsNavigationController") as? UIViewController
        {
            self.presentViewController(settingsNaivigationController, animated: true, completion: nil)
        }
    }

}
