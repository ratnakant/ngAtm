//
//  ContactDetailsViewController.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/15/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class ContactDetailsViewController: BaseFlowViewController, UITableViewDataSource, UITableViewDelegate {

    enum ContactDetails: String
    {
        case Name = "name"
        case Phones = "phones"
        case Emails = "emails"
        case Note = "note"
        case SendMessage = "sendMessage"
        case ShareContact = "shareContact"
        case SendRequestMoney = "sendRequestMoney"
        case AddToFavorites = "addToFavorites"
        case BlockThisCaller = "blockThisCaller"
        
        func getRowHeight() -> CGFloat
        {
            var height:CGFloat = 40.0
            switch self
            {
            case .Name, .Note:
                height = 85.0
            case .Phones, .Emails:
                height = 55.0
            case .AddToFavorites:
                height = 100.0
            default:
                height = 45.0
            }
            return height
        }
    }
    
    var sectionRowsDictionary = [ContactDetails:NSNumber]()
    var allContactDetails:[ContactDetails] = [.Name, .Phones, .Emails, .Note, .SendMessage, .ShareContact, .SendRequestMoney, .AddToFavorites, .BlockThisCaller]
    var displayedContactDetails = [ContactDetails]()
    
    func buildDisplayedContactDetails()
    {
        if let recipient = self.selectedRecipient
        {
            for contactDetail in self.allContactDetails
            {
                switch contactDetail
                {
                    case .Phones:
                        if (recipient.phones?.count > 0)
                        {
                            if let phones = recipient.phones
                            {
                                if (self.selectedRecipient?.selectedPhoneOrEmail == nil)
                                {
                                    self.selectedRecipient?.selectedPhoneOrEmail = phones.values.array[0]
                                }
                                self.sectionRowsDictionary[contactDetail] = NSNumber(long:phones.count)
                                self.displayedContactDetails.append(contactDetail)
                            }
                        }
                    case .Emails:
                        if (recipient.emails?.count > 0)
                        {
                            if let emails = recipient.emails
                            {
                                if (self.selectedRecipient?.selectedPhoneOrEmail == nil)
                                {
                                    self.selectedRecipient?.selectedPhoneOrEmail = emails.values.array[0]
                                }
                                self.sectionRowsDictionary[contactDetail] = NSNumber(long:emails.count)
                                self.displayedContactDetails.append(contactDetail)
                            }
                        }
                    default:
                        self.sectionRowsDictionary[contactDetail] = NSNumber(int:1)
                        self.displayedContactDetails.append(contactDetail)
                }
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.buildDisplayedContactDetails()
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return self.displayedContactDetails.count
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        var displayedContactDetail = self.displayedContactDetails[section]
        var rows = self.sectionRowsDictionary[displayedContactDetail]
        return rows!.integerValue
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        var returnedCell: UITableViewCell? = nil
        let contactDetail = self.displayedContactDetails[indexPath.section]
        switch (contactDetail)
        {
        case .Name:
            returnedCell = tableView.dequeueReusableCellWithIdentifier("ContactNameTableViewCell", forIndexPath: indexPath) as? ContactNameTableViewCell
        case .Phones:
            returnedCell = tableView.dequeueReusableCellWithIdentifier("ContactPhoneTableViewCell", forIndexPath: indexPath) as? ContactPhoneTableViewCell
        case .Emails:
            returnedCell = tableView.dequeueReusableCellWithIdentifier("ContactEmailTableViewCell", forIndexPath: indexPath) as? ContactEmailTableViewCell
        case .Note:
            returnedCell = tableView.dequeueReusableCellWithIdentifier("ContactNotesTableViewCell", forIndexPath: indexPath) as? ContactNotesTableViewCell
        case .SendMessage:
            if let cell = tableView.dequeueReusableCellWithIdentifier("ContactGeneralTableViewCell", forIndexPath: indexPath) as? ContactGeneralTableViewCell
            {
                cell.setupLabel("Send Message")
                returnedCell = cell
            }
        case .ShareContact:
            if let cell = tableView.dequeueReusableCellWithIdentifier("ContactGeneralTableViewCell", forIndexPath: indexPath) as? ContactGeneralTableViewCell
            {
                cell.setupLabel("Share Contact")
                returnedCell = cell
            }
        case .SendRequestMoney:
            if let cell = tableView.dequeueReusableCellWithIdentifier("ContactGeneralTableViewCell", forIndexPath: indexPath) as? ContactGeneralTableViewCell
            {
                cell.setupLabel("Send/Request Money")
                returnedCell = cell
            }
        case .AddToFavorites:
            if let cell = tableView.dequeueReusableCellWithIdentifier("ContactGeneralTableViewCell", forIndexPath: indexPath) as? ContactGeneralTableViewCell
            {
                cell.setupLabel("Add to Favorites")
                returnedCell = cell
            }
        case .BlockThisCaller:
            if let cell = tableView.dequeueReusableCellWithIdentifier("ContactGeneralTableViewCell", forIndexPath: indexPath) as? ContactGeneralTableViewCell
            {
                cell.setupLabel("Block this Caller")
                returnedCell = cell
            }
        }
        if let cell = returnedCell as? BaseContactDetailTableViewCell
        {
            if let recipient = self.selectedRecipient
            {
                cell.setupContact(recipient, rowIndex: indexPath.row)
            }
        }
        return returnedCell!
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat
    {
        let contactDetail = self.displayedContactDetails[indexPath.section]
        return contactDetail.getRowHeight()
    }
 
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let contactDetail = self.displayedContactDetails[indexPath.section]
        if (contactDetail == .SendRequestMoney)
        {
            if let viewController = self.storyboard?.instantiateViewControllerWithIdentifier("SendRequestMoneyViewController") as? SendRequestMoneyViewController
            {
                viewController.selectedRecipient = self.selectedRecipient
                viewController.mode = SendRequestMoneyViewController.Mode.SendMoneyMode
                self.navigationController?.pushViewController(viewController, animated: true)
            }
        }
    }
//    func tableView(tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat
//    {
//        let contactDetail = self.displayedContactDetails[section]
//        switch contactDetail
//        {
//            case .AddToFavorites:
//                return 100.0
//            case .BlockThisCaller:
//                return 0.0
//            default:
//                return 10.0
//        }
//    }
//    
//    func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView?
//    {
//        var viewHeight:CGFloat = 10.0
//        let contactDetail = self.displayedContactDetails[section]
//        if (contactDetail == .AddToFavorites)
//        {
//            viewHeight = 100.0
//        }
//        else if (contactDetail == .BlockThisCaller)
//        {
//            viewHeight = 0.0
//        }
//        else
//        {
//            viewHeight = 10.0
//        }
//        let footerView:UIView? = UIView(frame: CGRectMake(0.0, 0.0, tableView.frame.size.width, viewHeight))
//        if (contactDetail != .Name)
//        {
//            var footerSubview = UIView(frame: CGRectMake(15.0, 5.0, tableView.frame.size.width-15, 1.0))
//            footerSubview.backgroundColor = UIColor(red: 219/255.0, green: 219/255.0, blue: 219/255.0, alpha: 1.0)
//            footerView?.addSubview(footerSubview)
//        }
//        return footerView
//    }
    
}
