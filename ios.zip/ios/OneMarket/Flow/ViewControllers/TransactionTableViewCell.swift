//
//  TransactionTableViewCell.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/5/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class TransactionTableViewCell: UITableViewCell {

    @IBOutlet var amountLabel: UILabel?
    @IBOutlet var timeLabel: UILabel?
    @IBOutlet var memoLabel: UILabel?
    
    func setupTransaction(transaction:Transaction)
    {
        if let amount = transaction.amountInCurrency
        {
            self.amountLabel?.text = "You paid \(amount)"
        }
        self.timeLabel?.text = transaction.happenedOn
        self.memoLabel?.text = transaction.memo
    }
}
