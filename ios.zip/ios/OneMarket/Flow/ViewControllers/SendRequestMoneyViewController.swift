//
//  SendRequestMoneyViewController.swift
//  OneMarket
//
//  Created by Vijay Jain on 5/29/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit
import LocalAuthentication

class SendRequestMoneyViewController: BaseFlowViewController, UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource {

    enum Mode: Int
    {
        case SendMoneyMode
        case RequestMoneyMode
    }

    var mode:Mode?
    
    @IBOutlet var sendRequestMoneyView:UIView?
    @IBOutlet var transactionsView:UIView?

    @IBOutlet var sendMoneyView:UIView?
    @IBOutlet var requestMoneyView:UIView?

    @IBOutlet var nameLabel: UILabel?
    
    @IBOutlet var sendAmountTextField: UITextField?
    @IBOutlet var sendMemoTextField: UITextField?
    @IBOutlet var sendAmountView: UIView?
    @IBOutlet var sendMemoView: UIView?

    @IBOutlet var requestAmountTextField: UITextField?
    @IBOutlet var requestMemoTextField: UITextField?
    @IBOutlet var requestAmountView: UIView?
    @IBOutlet var requestMemoView: UIView?

    @IBOutlet var sendButton: UIButton?
    @IBOutlet var requeestButton: UIButton?
    @IBOutlet var payButton: UIButton?
    @IBOutlet var confirmPayButton: UIButton?
    @IBOutlet var progressView:UIView?

    @IBOutlet var transactionHeaderLabel: UILabel?
    var transactions:[Transaction]?
    let TransactionCellName = "TransactionCell"
    let NoTransactionCellName = "NoTransactionCell"
    
    var getTransactionsService:GetTransactionsService?
    
    @IBOutlet var transactionTableView: UITableView?

    var sendPaymentService:SendPaymentService?


    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.sendAmountView?.layer.borderColor = UIColor.colorWithHexString("272757", alpha: 0.6)?.CGColor
        self.sendAmountView?.layer.borderWidth = 1.0
        self.sendMemoView?.layer.borderColor = UIColor.colorWithHexString("272757", alpha: 0.6)?.CGColor
        self.sendMemoView?.layer.borderWidth = 1.0

        self.requestAmountView?.layer.borderColor = UIColor.colorWithHexString("272757", alpha: 0.6)?.CGColor
        self.requestAmountView?.layer.borderWidth = 1.0
        self.requestMemoView?.layer.borderColor = UIColor.colorWithHexString("272757", alpha: 0.6)?.CGColor
        self.requestMemoView?.layer.borderWidth = 1.0

        if let person = self.selectedRecipient
        {
            self.nameLabel?.text = person.displayName
        }
        self.modeChanged()
        self.sendButton?.setStyle("TabButton")
        self.requeestButton?.setStyle("TabButton")

        self.payButton?.enabled = false
        self.payButton?.setStyle("PrimaryButton")
        self.sendAmountTextField?.setStyle("InputTextField")
        self.sendMemoTextField?.setStyle("InputTextField")
        self.requestAmountTextField?.setStyle("InputTextField")
        self.requestMemoTextField?.setStyle("InputTextField")

        self.progressView?.hidden = true
        self.confirmPayButton?.setStyle("PrimaryButton")
        
        self.transactionsView?.hidden = true
        if let firstName = self.selectedRecipient?.firstName
        {
            self.transactionHeaderLabel?.text = "You and \(firstName)"
        }

    }

    override func viewWillAppear(animated: Bool)
    {
        super.viewWillAppear(animated)
        self.downloadTransactionsHistory()
    }
    
    func amountValueChanged()
    {
        var amountTextField:UITextField? = nil
        if (self.mode == .SendMoneyMode)
        {
            amountTextField = self.sendAmountTextField
        }
        else
        {
            amountTextField = self.requestAmountTextField
        }
        if let amountText = amountTextField?.text
        {
            if (amountText.isEmpty == false)
            {
                let amount = (amountText as NSString).floatValue
                if (amount > 0)
                {
                    self.payButton?.enabled = true
                    self.payButton?.setStyle("PrimaryButton")
                    
                    var numberFormatter = NSNumberFormatter()
                    numberFormatter.numberStyle = NSNumberFormatterStyle.CurrencyStyle
                    amountTextField?.text = numberFormatter.stringFromNumber(amount)
                }
            }
        }
    }


    @IBAction func payButtonTouched(sender:AnyObject?)
    {
        var amountTextField:UITextField? = nil
        var memoTextField:UITextField? = nil
        if (self.mode == .SendMoneyMode)
        {
            amountTextField = self.sendAmountTextField
            memoTextField = self.sendMemoTextField
        }
        else
        {
            amountTextField = self.requestAmountTextField
            memoTextField = self.requestMemoTextField
        }

        self.sendAmountTextField?.resignFirstResponder()
        self.sendMemoTextField?.resignFirstResponder()
        self.requestAmountTextField?.resignFirstResponder()
        self.requestMemoTextField?.resignFirstResponder()

        if (self.mode == .SendMoneyMode)
        {
            UIView.animateWithDuration(0.5, animations:
            {
                self.payButton?.transform = CGAffineTransformMakeTranslation(-300.0, 0.0)
            }, completion: {
                [weak self]
                (value: Bool) in
                if (value == true)
                {
                    if let strongSelf = self
                    {
                        strongSelf.payButton?.hidden = true
                        strongSelf.animateConfirmButtonFromLeftToRight()
                    }
                }
            })
        }
    }
    
    func animateConfirmButtonFromLeftToRight()
    {
        self.confirmPayButton?.hidden = false
        var app = UIApplication.sharedApplication()
        UIView.animateWithDuration(0.5, animations:
            {
                if let window = UIApplication.sharedApplication().keyWindow
                {
                    if let confirmButton = self.confirmPayButton
                    {
                        var xValue = -1 * (window.frame.size.width/2+confirmButton.frame.size.width/2)
                        self.confirmPayButton?.transform = CGAffineTransformMakeTranslation(xValue, 0.0)
                    }
                }
            }, completion: {
                [weak self]
                (value: Bool) in
                if (value == true)
                {
                    if let strongSelf = self
                    {
                    }
                }
            })
    }

    @IBAction func confirmPayButtonTouched(sender:AnyObject?)
    {
        var amountTextField:UITextField? = nil
        var memoTextField:UITextField? = nil
        if (self.mode == .SendMoneyMode)
        {
            amountTextField = self.sendAmountTextField
            memoTextField = self.sendMemoTextField
        }
        else
        {
            amountTextField = self.requestAmountTextField
            memoTextField = self.requestMemoTextField
        }

        self.selectedRecipient?.amount = amountTextField?.text
        self.selectedRecipient?.memo = memoTextField?.text

        self.authenticateUser()
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
        if segue.identifier == "SegueToConfirmPay"
        {
            var amountTextField:UITextField? = nil
            var memoTextField:UITextField? = nil
            if (self.mode == .SendMoneyMode)
            {
                amountTextField = self.sendAmountTextField
                memoTextField = self.sendMemoTextField
            }
            else
            {
                amountTextField = self.requestAmountTextField
                memoTextField = self.requestMemoTextField
            }

            self.selectedRecipient?.amount = amountTextField?.text
            self.selectedRecipient?.memo = memoTextField?.text
            
            var viewController = segue.destinationViewController as? ConfirmPayViewController
            viewController?.selectedRecipient = self.selectedRecipient
            
        }
    }
    
    @IBAction func historyButtonTouched(sender:AnyObject?)
    {
        self.switchBetweenSendRequestMoneyAndTransactionView()
    }
    
    func switchBetweenSendRequestMoneyAndTransactionView()
    {
        if (self.sendRequestMoneyView?.hidden == false)
        {
            self.sendRequestMoneyView?.hidden = true
            self.transactionsView?.hidden = false
        }
        else
        {
            self.sendRequestMoneyView?.hidden = false
            self.transactionsView?.hidden = true
        }
    }
    
    @IBAction func handleSingleTap (recognizer: UITapGestureRecognizer)
    {
        var amountTextField:UITextField? = nil
        var memoTextField:UITextField? = nil
        if (self.mode == .SendMoneyMode)
        {
            amountTextField = self.sendAmountTextField
            memoTextField = self.sendMemoTextField
        }
        else
        {
            amountTextField = self.requestAmountTextField
            memoTextField = self.requestMemoTextField
        }
        amountTextField?.resignFirstResponder()
        memoTextField?.resignFirstResponder()
    }
    
    func textFieldDidEndEditing(textField: UITextField)
    {
        self.amountValueChanged()
    }
    
    func modeChanged()
    {
        if (self.mode == .SendMoneyMode)
        {
            self.sendMoneyView?.hidden = false
            self.requestMoneyView?.hidden = true
            
            self.sendButton?.selected = true
            self.requeestButton?.selected = false
            self.payButton?.setTitle("Send Money", forState: UIControlState.Normal)
        }
        else
        {
            self.sendMoneyView?.hidden = true
            self.requestMoneyView?.hidden = false

            self.sendButton?.selected = false
            self.requeestButton?.selected = true
            self.payButton?.setTitle("Request Money", forState: UIControlState.Normal)
        }
    }
    
    @IBAction func sendButtonTouched(sender:AnyObject?)
    {
        self.mode = .SendMoneyMode
        self.modeChanged()
    }

    @IBAction func requestButtonTouched(sender:AnyObject?)
    {
        self.mode = .RequestMoneyMode
        self.modeChanged()
    }
    
    func authenticateUser()
    {
        let context = LAContext()
        var error: NSError?
        var reasonString = "Authentication is needed to send the money."
        if context.canEvaluatePolicy(LAPolicy.DeviceOwnerAuthenticationWithBiometrics, error: &error)
        {
            context.evaluatePolicy(LAPolicy.DeviceOwnerAuthenticationWithBiometrics, localizedReason: reasonString, reply: { (success: Bool, evalPolicyError: NSError?) -> Void in
                if (success == true)
                {
                    self.sendPayment()
                    dispatch_async(dispatch_get_main_queue()) {
                        self.confirmPayButton?.hidden = true
                        self.progressView?.hidden = false
                    }
                }
                else
                {
                    dispatch_async(dispatch_get_main_queue()) {
                        self.displayTouchIdError(evalPolicyError)
                    }
                }
                
            })
        }
    }
    
    func sendPayment()
    {
        self.sendPaymentService = SendPaymentService()
        if let selectedRecipient = self.selectedRecipient
        {
            self.sendPaymentService?.sendPaymentTo(selectedRecipient, errorHandler: { (error:NSError?) -> () in
                self.displayError(error)
                },  completionHandler:{ () -> () in
                    
                    dispatch_async(dispatch_get_main_queue()) {
                        if let transaction = self.createTransaction()
                        {
                            self.transactions?.insert(transaction, atIndex: 0)
                            self.animateTransaction(transaction)
                        }
                    }
            })
        }
    }
    
    func createTransaction() ->Transaction?
    {
        var aTransaction:Transaction? = nil
        if let selectedRecipient = self.selectedRecipient
        {
            var numberFormatter = NSNumberFormatter()
            numberFormatter.numberStyle = NSNumberFormatterStyle.CurrencyStyle

            aTransaction = Transaction()
            aTransaction?.amountInCurrency = selectedRecipient.amount
            aTransaction?.memo = selectedRecipient.memo
            aTransaction?.selectedPhoneOrEmail = selectedRecipient.selectedPhoneOrEmail
            aTransaction?.transactionDate = NSDate()
            aTransaction?.type = .Send
        }
        return aTransaction
    }
    
    override func displayError(error:NSError?)
    {
        dispatch_async(dispatch_get_main_queue()) {
            self.progressView?.hidden = true
            self.confirmPayButton?.enabled = true
            super.displayError(error)
        }
    }
    
    func displayTouchIdError(evalPolicyError:NSError?)
    {
        println(evalPolicyError?.localizedDescription)
        
        switch evalPolicyError!.code
        {
        case LAError.SystemCancel.rawValue:
            println("Authentication was cancelled by the system")
            
        case LAError.UserCancel.rawValue:
            println("Authentication was cancelled by the user")
            
        case LAError.UserFallback.rawValue:
            println("User selected to enter custom password")
            //                NSOperationQueue.mainQueue().addOperationWithBlock({ () -> Void in
            //                    self.showPasswordAlert()
            //                })
            
        default:
            println("Authentication failed")
            //                NSOperationQueue.mainQueue().addOperationWithBlock({ () -> Void in
            //                    self.showPasswordAlert()
            //            })
        }
    }

    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool
    {
        var amountTextField:UITextField? = nil
        if (self.mode == .SendMoneyMode)
        {
            amountTextField = self.sendAmountTextField
        }
        else
        {
            amountTextField = self.requestAmountTextField
        }
        if let amountText = amountTextField?.text
        {
            if (amountText.isEmpty == false)
            {
                if (self.mode == .SendMoneyMode)
                {
                    amountTextField = self.sendAmountTextField
                }
                else
                {
                    amountTextField = self.requestAmountTextField
                }
                let amount = (amountText as NSString).floatValue
                if (amount > 0)
                {
                    self.payButton?.enabled = true
                    //self.payButton?.setStyle("PrimaryButton")
                }
            }
        }
        return true
    }
    
    func animateTransaction(transaction:Transaction)
    {
        var amountTextField:UITextField? = nil
        var memoTextField:UITextField? = nil
        if (self.mode == .SendMoneyMode)
        {
            amountTextField = self.sendAmountTextField
            memoTextField = self.sendMemoTextField
        }
        else
        {
            amountTextField = self.requestAmountTextField
            memoTextField = self.requestMemoTextField
        }
        
        self.switchBetweenSendRequestMoneyAndTransactionView()

        self.payButton?.transform = CGAffineTransformIdentity
        self.payButton?.hidden = false
        self.payButton?.enabled = false
        
        self.confirmPayButton?.hidden = true
        self.progressView?.hidden = true
        
        amountTextField?.text = ""
        memoTextField?.text = ""

        let delayTime = dispatch_time(DISPATCH_TIME_NOW, Int64(0.5 * Double(NSEC_PER_SEC)))
        dispatch_after(delayTime, dispatch_get_main_queue()) {
        self.transactionTableView?.beginUpdates()
            var indexPath:NSIndexPath = NSIndexPath(forRow: 0, inSection: 0)
            self.transactionTableView?.insertRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.Top)
        }
        self.transactionTableView?.endUpdates()
    }

    func downloadTransactionsHistory()
    {
        self.getTransactionsService = GetTransactionsService()
        if let selectedRecipient = self.selectedRecipient
        {
            self.getTransactionsService?.getTransactions(selectedRecipient, errorHandler: { (error:NSError?) -> () in
                self.displayError(error)
                },  completionHandler:{ () -> () in
                    
                    dispatch_async(dispatch_get_main_queue()) {
                        self.transactions = self.getTransactionsService?.transactions
                        self.transactionTableView?.reloadData()
                    }
            })
        }
    }

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        var rowsCount = 0
        if let transactions = self.transactions
        {
            rowsCount = transactions.count
        }
        return rowsCount
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        var returnedCell: UITableViewCell? = nil
        
        if let transactions = self.transactions
        {
            if transactions.count > 0 {
                
                let cell = tableView.dequeueReusableCellWithIdentifier(self.TransactionCellName, forIndexPath: indexPath) as? TransactionTableViewCell
                
                if let transaction = self.transactions?[indexPath.row]  {
                    cell?.setupTransaction(transaction)
                }
                
                cell?.selectionStyle = UITableViewCellSelectionStyle.None
                returnedCell = cell
                
            } else {
                
                let cell = tableView.dequeueReusableCellWithIdentifier(self.NoTransactionCellName, forIndexPath: indexPath) as? UITableViewCell
                cell?.selectionStyle = UITableViewCellSelectionStyle.None
                cell?.textLabel?.text = "No transaction found"
                returnedCell = cell
            }
        }
        
        return returnedCell!
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 60.0
    }

}
