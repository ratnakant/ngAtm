//
//  ContactViewController.swift
//  OneMarket
//
//  Created by Vijay Jain on 5/27/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class ContactViewController: BaseFlowViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet var nameLabel: UILabel?
    @IBOutlet var emailPhoneTableView: UITableView?
    @IBOutlet var payButton: UIButton?
    @IBOutlet var requestButton: UIButton?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let person = self.selectedRecipient
        {
            self.nameLabel?.text = person.displayName
        }
        self.emailPhoneTableView?.registerClass(UITableViewCell.classForCoder(), forCellReuseIdentifier: "EmailPhoneTableViewCell")
        self.payButton?.enabled = false
        self.requestButton?.enabled = false
        
        self.payButton?.setStyle("PrimaryButton")
        self.requestButton?.setStyle("PrimaryButton")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        if (self.selectedRecipient?.phones?.count > 0) && (self.selectedRecipient?.emails?.count > 0)
        {
            return 2
        }
        else if (self.selectedRecipient?.phones?.count > 0) || (self.selectedRecipient?.emails?.count > 0)
        {
            return 1
        }
        else
        {
            return 0
        }
    }

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        var numberOfRows = 0
        if (self.selectedRecipient?.phones?.count > 0) && (self.selectedRecipient?.emails?.count > 0)
        {
            if (section == 1)
            {
                numberOfRows = self.selectedRecipient!.emails!.count
            }
            else
            {
                numberOfRows = self.selectedRecipient!.phones!.count
            }
        }
        else if (self.selectedRecipient?.emails?.count > 0)
        {
            numberOfRows = self.selectedRecipient!.emails!.count
        }
        else if (self.selectedRecipient?.phones?.count > 0)
        {
            numberOfRows = self.selectedRecipient!.phones!.count
        }
        return numberOfRows
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        var aCell:UITableViewCell? = nil
        
        if let cell = tableView.dequeueReusableCellWithIdentifier("EmailPhoneTableViewCell") as? UITableViewCell
        {
            if (self.selectedRecipient?.phones?.count > 0) && (self.selectedRecipient?.emails?.count > 0)
            {
                if (indexPath.section == 1)
                {
                    var key = self.selectedRecipient!.emails!.keys.array[indexPath.row]
                    cell.textLabel?.text = self.selectedRecipient!.emails![key]
                }
                else
                {
                    var key = self.selectedRecipient!.phones!.keys.array[indexPath.row]
                    cell.textLabel?.text = self.selectedRecipient!.phones![key]
                }
            }
            else if (self.selectedRecipient?.emails?.count > 0)
            {
                var key = self.selectedRecipient!.emails!.keys.array[indexPath.row]
                cell.textLabel?.text = self.selectedRecipient!.emails![key]
            }
            else if (self.selectedRecipient?.phones?.count > 0)
            {
                var key = self.selectedRecipient!.phones!.keys.array[indexPath.row]
                cell.textLabel?.text = self.selectedRecipient!.phones![key]
            }
            aCell = cell;
        }
        return aCell!;
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        var headerView:UIView? = nil
        if (self.selectedRecipient?.phones?.count > 0) && (self.selectedRecipient?.emails?.count > 0)
        {
            if (section == 1)
            {
                headerView = self.createSectionHeaderForLabel("Emails")
            }
            else
            {
                headerView = self.createSectionHeaderForLabel("Phones")
            }
        }
        else if (self.selectedRecipient?.emails?.count > 0)
        {
            headerView = self.createSectionHeaderForLabel("Emails")
        }
        else if (self.selectedRecipient?.phones?.count > 0)
        {
            headerView = self.createSectionHeaderForLabel("Phones")
        }
        return headerView
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
            return 40.0
    }

    func createSectionHeaderForLabel (text: String) -> UIView?
    {
        let titleLabel = UILabel()
        titleLabel.textAlignment = NSTextAlignment.Left
        let font = UIFont(name: "FreightSansLining-Medium", size: 31)
        titleLabel.font = font
        titleLabel.text = text
        titleLabel.textColor = UIColor.blueColor()
        
        let viewFrame = CGRectMake(0, 0, self.view.frame.width, 40)
        let headerView = UIView(frame: viewFrame)
        
        headerView.addSubview(titleLabel)
        titleLabel.frame = CGRectMake(10, 3, viewFrame.width, 35)
        
        return headerView
    }

    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        if (self.selectedRecipient?.phones?.count > 0) && (self.selectedRecipient?.emails?.count > 0)
        {
            if (indexPath.section == 1)
            {
                var key = self.selectedRecipient!.emails!.keys.array[indexPath.row]
                self.selectedRecipient?.selectedPhoneOrEmail = self.selectedRecipient!.emails![key]
            }
            else
            {
                var key = self.selectedRecipient!.phones!.keys.array[indexPath.row]
                self.selectedRecipient?.selectedPhoneOrEmail = self.selectedRecipient!.phones![key]
            }
        }
        else if (self.selectedRecipient?.emails?.count > 0)
        {
            var key = self.selectedRecipient!.emails!.keys.array[indexPath.row]
            self.selectedRecipient?.selectedPhoneOrEmail = self.selectedRecipient!.emails![key]
        }
        else if (self.selectedRecipient?.phones?.count > 0)
        {
            var key = self.selectedRecipient!.phones!.keys.array[indexPath.row]
            self.selectedRecipient?.selectedPhoneOrEmail = self.selectedRecipient!.phones![key]
        }

        self.payButton?.enabled = true
        self.requestButton?.enabled = true
    }

    // MARK: - Navigation

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
        if segue.identifier == "SegueToSendMoney"
        {
            if let tabBarController = segue.destinationViewController as? UITabBarController
            {
                for childViewController in tabBarController.viewControllers!
                {
                    if let navigationViewController = childViewController as? UINavigationController
                    {
                        if let viewController = navigationViewController.viewControllers[0] as? SendRequestMoneyViewController
                        {
                            viewController.selectedRecipient = self.selectedRecipient
                            viewController.title = "Send Money"
                            viewController.mode = .SendMoneyMode
                            viewController.tabBarItem.title = "Send Money"
                        }
                        else if let viewController = navigationViewController.viewControllers[0] as? SeeHistoryViewController
                        {
                            viewController.selectedRecipient = self.selectedRecipient
                        }
                    }
                }
            }
        }
        else if segue.identifier == "SegueToRequestMoney"
        {
            if let tabBarController = segue.destinationViewController as? UITabBarController
            {
                for childViewController in tabBarController.viewControllers!
                {
                    if let navigationViewController = childViewController as? UINavigationController
                    {
                        if let viewController = navigationViewController.viewControllers[0] as? SendRequestMoneyViewController
                        {
                            viewController.selectedRecipient = self.selectedRecipient
                            viewController.title = "Request Money"
                            viewController.mode = .RequestMoneyMode
                            viewController.tabBarItem.title = "Request Money"
                        }
                        else if let viewController = navigationViewController.viewControllers[0] as? SeeHistoryViewController
                        {
                            viewController.selectedRecipient = self.selectedRecipient
                        }
                    }
                }
            }
        }
    }

}
