//
//  Transaction.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/5/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class Transaction: NSObject {
   
    enum Type:Int16
    {
        case Unknown
        case Send
        case Receive
    }
    
    var selectedPhoneOrEmail:String?
    var displayName: String?

    var amountInCurrency: String?
    var memo: String?
    var transactionDate: NSDate?
    var type:Type?
    
    var happenedOn:String
    {
        get
        {
            var returnString:String = ""
            
            if let transactionDate = self.transactionDate
            {
                var secondsPast = NSDate().timeIntervalSinceDate(transactionDate) as NSTimeInterval
                if (secondsPast <= 60.0)
                {
                    returnString = "a min ago"
                }
                else
                {
                    if (secondsPast < 3600.0)
                    {
                        var minutesPast:Int =  Int(secondsPast/60.0)
                        if (minutesPast <= 1)
                        {
                            returnString = "a min ago"
                        }
                        else
                        {
                            returnString = "\(minutesPast) mins ago"
                        }
                    }
                    else if (secondsPast < 3600.0 * 24.0)
                    {
                        var hoursPast:Int =  Int(secondsPast/3600.0)
                        if (hoursPast <= 1)
                        {
                            returnString = "\(hoursPast) hr ago"
                        }
                        else
                        {
                            returnString = "\(hoursPast) hrs ago"
                        }
                    }
                    else
                    {
                        var numberOfDays:Int = Int(secondsPast / 86400)
                        if (numberOfDays <= 1)
                        {
                            returnString = "yesterday"
                        }
                        else
                        {
                            returnString = "\(numberOfDays) days ago"
                        }
                    }
                }
            }
            return returnString
        }
    }

}
