//
//  User.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/3/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class User: NSObject
{
    
    
    class var accessToken:String? {
        get {
            return "26c62ee4ee7c455a2840aa8ee80e722fe069e8962d54b5055b5a29dc1d7480277e5fda1530545691563c03a8e07ee26f22729edfcc6862b40f52c9f5436abd43c76a8bc0d00a30a4c62ca3e4476786b3bd43b807dbdee24e886db63cf5b6e5831454ab0e72665528c7cbc0c4c52fc67806e951be16db59eb723aa55e8b4727f3e6d0c12591dc8cb4e326decc7e5d0bcd67af01e0a9ac2363bce20239aa318a0b9f0e97"
//            if let userId =  NSUserDefaults.standardUserDefaults().objectForKey("LastUserIdKey") as? String
//            {
//                return NSUserDefaults.standardUserDefaults().objectForKey(userId) as? String
//            }
//            return nil
        }
    }
    
    class func retrieveLastUser() -> User?
    {
        var user:User? = nil
        if let userId =  NSUserDefaults.standardUserDefaults().objectForKey("LastUserIdKey") as? String
        {
            if let accessToken = NSUserDefaults.standardUserDefaults().objectForKey(userId) as? String
            {
                user = User(userId: userId, accessToken:accessToken)
            }
        }
        return user
    }
    
    class func removeLastUser()
    {
        NSUserDefaults.standardUserDefaults().removeObjectForKey("LastUserIdKey")
        NSUserDefaults.standardUserDefaults().synchronize()
    }
    
    
    init(userId: String, accessToken: String)
    {
        NSUserDefaults.standardUserDefaults().setObject(accessToken, forKey: userId)
        NSUserDefaults.standardUserDefaults().synchronize()
    }

}
