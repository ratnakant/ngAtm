//
//  UserPreferences.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/2/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

let environmentKey = "Environment"

class UserPreferences: NSObject
{
    class var environment: String?
    {
        get
        {
            return  NSUserDefaults.standardUserDefaults().objectForKey(environmentKey) as? String
        }
            set
        {
            NSUserDefaults.standardUserDefaults().setObject(newValue, forKey: environmentKey)
            NSUserDefaults.standardUserDefaults().synchronize()
        }
    }
}
