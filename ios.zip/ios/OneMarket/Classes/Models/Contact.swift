//
//  Person.swift
//  OneMarket
//
//  Created by Vijay Jain on 5/28/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class Contact: NSObject {
 
    var firstName: String?
    var lastName: String?
    var companyName: String?

    var displayName: String?
    {
        get
        {
            if (self.firstName != nil) && (self.lastName != nil)
            {
                 return "\(self.firstName!) \(self.lastName!)"
            }
            else if (self.firstName != nil)
            {
                 return "\(self.firstName!)"
            }
            else if (self.lastName != nil)
            {
                return "\(self.lastName!)"
            }
            else
            {
                return ""
            }
        }
    }
    
    var phones: [String:String]?
    var emails: [String:String]?
    
    var selectedPhoneOrEmail:String?
    
    
}
