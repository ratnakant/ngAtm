//
//  Device.swift
//  OneMarket
//
//  Created by Vijay Jain on 5/27/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class Device: NSObject {
    
    class func isiPhone6OrAbove() -> Bool
    {
        var returnValue = false
    
        var platform = Device.hardwarePlatform()
        if platform == "x86_64"
        {
            var screenWidth:CGFloat = 0.0;
            var interfaceOrientation = UIApplication.sharedApplication().statusBarOrientation
            if (UIInterfaceOrientationIsPortrait(interfaceOrientation))
            {
                screenWidth = UIScreen.mainScreen().bounds.size.width
            }
            else
            {
                screenWidth = UIScreen.mainScreen().bounds.size.height
            }
        
            if (screenWidth >= 375)
            {
                returnValue = true
            }
        }
        else if (platform == "iPhone7,1") || (platform == "iPhone7,2")
        {
            returnValue = true
        }
        return returnValue;
    }

    class func iOSVersion() ->String
    {
        return UIDevice.currentDevice().systemVersion
    }
    
    class func hardwarePlatform() -> String
    {
        if let key = "hw.machine".cStringUsingEncoding(NSUTF8StringEncoding)
        {
            var size : Int = 0
            sysctlbyname(key, nil, &size, nil, 0)
            var machine = [CChar](count: Int(size), repeatedValue: 0)
            sysctlbyname(key, &machine, &size, nil, 0)
            return String.fromCString(machine)!
        }
        return ""
    }
    
    class func isiPhone5() -> Bool
    {
        var device = Device.hardwarePlatform()
        if device.hasPrefix("iPhone5") == true
        {
            return true
        }
        return false
    }
    
}
