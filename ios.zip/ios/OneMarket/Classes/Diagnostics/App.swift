//
//  App.swift
//  OneMarket
//
//  Created by Vijay Jain on 5/27/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class App: NSObject {
 
    class var appName : String?
    {
        get
        {
            if let infoDictionary = NSBundle.mainBundle().infoDictionary as NSDictionary?
            {
                return  infoDictionary.objectForKey("CFBundleExecutable") as? String
            }
            return nil
        }
    }
    
    class var appVersion : String?
    {
        get
        {
            if let infoDictionary = NSBundle.mainBundle().infoDictionary as NSDictionary?
            {
                return  infoDictionary.objectForKey("CFBundleShortVersionString") as? String
            }
            return nil
        }
    }
    
    class var appBuildNumber: String?
    {
        get
        {
            if let infoDictionary = NSBundle.mainBundle().infoDictionary as NSDictionary?
            {
                return infoDictionary.objectForKey("CFBundleVersion") as? String
            }
            return nil
        }
    }
    
    class var appVersionAndBuildNumber: String?
    {
        get
        {
            if let version = App.appVersion
            {
                if let build = App.appBuildNumber
                {
                    return "\(version).\(build)"
                }
            }
            return nil
        }
    }
    
    class func generateNewSessionId() -> String
    {
        return NSUUID().UUIDString
        
    }

}
