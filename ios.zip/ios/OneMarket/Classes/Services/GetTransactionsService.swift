//
//  GetTransactionsService.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/8/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class GetTransactionsService: BaseService {
   
    var transactions: [Transaction]?
    
    func getTransactions(recipient:Recipient, errorHandler:(error:NSError?) -> (), completionHandler:()->())
    {
        if let recipientId = recipient.selectedPhoneOrEmail
        {
            var requestUrl = ConfiguredService.transactionHistoryURL(recipientId)
            self.sendRequest(requestUrl, errorHandler:errorHandler, completionHandler:completionHandler)
        }
    }

    override func parseResponseDictionary(dictionary:NSDictionary) -> Bool
    {
        self.transactions = [Transaction]()
        
        var numberFormatter = NSNumberFormatter()
        numberFormatter.numberStyle = NSNumberFormatterStyle.CurrencyStyle
        
        var utcDateFormatter = NSDateFormatter()
        utcDateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
        
        if let transactions = dictionary["transactions"] as? NSArray
        {
            for transaction in transactions
            {
                if let transactionDict = transaction as? NSDictionary
                {
                    var aTransaction = Transaction()
                    if let amount = transactionDict["amount"] as? NSNumber
                    {
                        let amountInDollars = NSNumber(float:(amount.floatValue/100.0))
                        aTransaction.amountInCurrency = numberFormatter.stringFromNumber(amountInDollars)
                    }
                    aTransaction.memo = transactionDict["memo"] as? String
                    aTransaction.selectedPhoneOrEmail = transactionDict["receiver_uid"] as? String
                    if let transactionDate = transactionDict["created"] as? String
                    {
                        aTransaction.transactionDate = utcDateFormatter.dateFromString(transactionDate)
                    }
                    if let type = transactionDict["type"] as? String
                    {
                        if type == "S"
                        {
                            aTransaction.type = .Send
                        }
                        else if type == "R"
                        {
                            aTransaction.type = .Receive
                        }
                    }
                    self.transactions?.append(aTransaction)
                }
            }
        }
        return true
    }

}
