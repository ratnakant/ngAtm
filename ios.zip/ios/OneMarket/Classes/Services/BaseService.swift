//
//  BaseService.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/8/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class BaseService: NSObject {
   
    var serviceAgent:ServiceAgent?

    override init()
    {
        self.serviceAgent = ServiceAgent()
        super.init()
    }
    
    func sendRequest(requestUrl:String?, errorHandler:(error:NSError?) -> (), completionHandler:()->())
    {
        if let urlRequest = serviceAgent?.createRequest(requestUrl, postData: self.createPostData())
        {
            var requestStartTime = NSDate()
            NSLog("Request \(urlRequest.description) started at: \(requestStartTime)")
            serviceAgent?.sendRequest(urlRequest: urlRequest, errorHandler: errorHandler, parseResponse: {
                (responseDictionary) -> Bool in
                var returnValue = false
                if let dictionary = responseDictionary
                {
                    returnValue = true
                    if self.parseResponseDictionary(dictionary) == true
                    {
                        completionHandler()
                    }
                    else
                    {
                        var string = NSLocalizedString("Request failed. Please try again later", comment:"")
                        var userInfo = [NSLocalizedDescriptionKey: string]
                        var anError = NSError(domain: "Service Error", code: -200, userInfo: userInfo)
                        errorHandler(error: anError)
                    }
                }
                return returnValue
            })
        }
    }
    
    func createPostData() -> NSData?
    {
        return nil
    }
    
    func parseResponseDictionary(dictionary:NSDictionary) -> Bool
    {
        return true
    }
}
