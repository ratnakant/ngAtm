//
//  ServiceAgent.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/3/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class ServiceAgent: NSObject, NSURLSessionDelegate
{
    let timeoutInterval:NSTimeInterval = 30.0
    
    func createRequest(requestURL: String?, postData: NSData? = nil) -> NSMutableURLRequest?
    {
        var request: NSMutableURLRequest? = nil
        if let encodedURL = requestURL?.stringByAddingPercentEscapesUsingEncoding(NSUTF8StringEncoding)
        {
            request = NSMutableURLRequest(URL: NSURL(string: encodedURL)!, cachePolicy: NSURLRequestCachePolicy.ReloadIgnoringLocalCacheData, timeoutInterval: timeoutInterval)
            request?.setValue("application/json", forHTTPHeaderField:"Content-Type")
            
//            if let accessToken = AuthManager.sharedInstance.authenticatedUser?.accessToken as String?
            if let accessToken = User.accessToken as String?
            {
                if count(accessToken) > 0 {
                    request?.setValue(accessToken, forHTTPHeaderField: "authorization")
                }
            }
            
            if (postData != nil)
            {
                request?.HTTPBody = postData
                request?.HTTPMethod = "POST"
            }
            else
            {
                request?.HTTPMethod = "GET"
            }
        }
        return request
    }
    
    func convertToJSONDictionary(data:NSData)-> NSDictionary?
    {
        var dictionary:NSDictionary? = nil
        var error:NSError? = nil
        dictionary = NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions.MutableContainers, error: &error) as? NSDictionary
        return dictionary
    }
    
    func sendRequest (urlRequest aUrlRequest: NSURLRequest?, errorHandler:(error:NSError?) ->(), parseResponse: (responseDictionay: NSDictionary?) -> Bool) {
        
        if let urlRequest = aUrlRequest
        {
            NSLog("Sending request to URL: \(urlRequest.URL!.absoluteString)")
            let sessionConfiguration = NSURLSessionConfiguration.defaultSessionConfiguration()
            let session = NSURLSession(configuration: sessionConfiguration, delegate: self, delegateQueue: nil)
            
            session.dataTaskWithRequest(urlRequest, completionHandler:
            { (data, response, error) -> Void in
                
                if let anError = error
                {
                    NSLog("ERROR: \(anError)")
                    errorHandler(error: anError)
                    return
                }
                    
                if let urlResponse = response as? NSHTTPURLResponse
                {
                    if  urlResponse.statusCode == 200 || urlResponse.statusCode == 201
                    {
                        if let responseData = data where responseData.bytes != nil
                        {
                            var jsonError: NSError?
                            let jsonDictionary = NSJSONSerialization.JSONObjectWithData(responseData, options: NSJSONReadingOptions.allZeros, error: &jsonError) as? [NSObject: AnyObject]
                            if let anError = jsonError
                            {
                                errorHandler(error: anError)
                                return
                            }
                            let status = parseResponse(responseDictionay:jsonDictionary)
                            if status == false
                            {
                                var string = NSLocalizedString("Could not parse the response successfully.", comment:"")
                                var userInfo = [NSLocalizedDescriptionKey: string]
                                var anError = NSError(domain: "Parse Error", code: -100, userInfo: userInfo)
                                errorHandler(error: anError)
                                return
                            }
                        }
                    }
                    else
                    {
                        NSLog("Response failed with error code: \(urlResponse.statusCode)")
                    }
                }
            }).resume()
        }
    }

}
