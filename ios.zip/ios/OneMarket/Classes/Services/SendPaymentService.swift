//
//  SendPaymentService.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/4/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class SendPaymentService: BaseService
{
    var recipient:Recipient?
    
    func sendPaymentTo(recipient:Recipient, errorHandler:(error:NSError?) -> (), completionHandler:()->())
    {
        var requestUrl = ConfiguredService.sendPaymentURL()
        self.recipient = recipient
        
        self.sendRequest(requestUrl, errorHandler:errorHandler, completionHandler:completionHandler)
    }
    
    override func createPostData() -> NSData?
    {
        var jsonPostData: NSData? = nil
        if let recipient = self.recipient
        {
            var dictionary = NSMutableDictionary()
            var error: NSError?
            
            var recipientDictionary = NSMutableDictionary()
            recipientDictionary.setObject(recipient.selectedPhoneOrEmail!, forKey: "receiver_uid")
            
            var numberFormatter = NSNumberFormatter()
            numberFormatter.numberStyle = NSNumberFormatterStyle.CurrencyStyle

            if let amount = numberFormatter.numberFromString(recipient.amount!)
            {
                var amountInCents:Int32 = Int32(amount.floatValue * 100)
                recipientDictionary.setObject(NSNumber(int: amountInCents), forKey: "amount")
            }
            recipientDictionary.setObject("USD", forKey: "currency")
            recipientDictionary.setObject("S", forKey: "type")
            if let memo = recipient.memo
            {
                recipientDictionary.setObject(memo, forKey: "memo")
            }
            
            jsonPostData = NSJSONSerialization.dataWithJSONObject(recipientDictionary, options: NSJSONWritingOptions.allZeros, error: &error)
            
            //                var jsonPostDataAsString = NSString(data: jsonPostData!, encoding: NSUTF8StringEncoding) // For debug purposes
            //                dlog("jsonPostDataAsString: \(jsonPostDataAsString)")
        }
        return jsonPostData
    }
    
    override func parseResponseDictionary(dictionary:NSDictionary) -> Bool
    {
        var success: Bool = false
        if let successResponse = dictionary["success"] as? NSString
        {
            success = true
        }
        return success
    }

}
