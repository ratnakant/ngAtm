//
//  ConfiguredService.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/2/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class ConfiguredService: NSObject {
 
    var configServiceDictionary: NSDictionary?
    
    override init()
    {
        if let plistPath = NSBundle.mainBundle().pathForResource("ConfigService", ofType: "plist")
        {
            self.configServiceDictionary = NSDictionary(contentsOfFile: plistPath)
        }
    }
    
    class var sharedInstance:ConfiguredService
    {
        struct Static
        {
            static var instance : ConfiguredService? = nil
            static var onceToken : dispatch_once_t = 0
        }
        
        dispatch_once(&Static.onceToken)
            {
                Static.instance = ConfiguredService()
        }
        
        return Static.instance!
    }

    private class var environment : String
    {
        get
        {
            if let anEnvironment = UserPreferences.environment
            {
                return anEnvironment;
            }
            else
            {
                if let anEnvironment = ConfiguredService.sharedInstance.configServiceDictionary?.objectForKey(environmentKey) as? String
                {
                    return anEnvironment
                }
                else
                {
                    return "Dev"
                }
            }
        }
    }
    
    class func stringForKey(key: String, environment: String = ConfiguredService.environment) -> String?
    {
        let serviceDictionaryForEnv = ConfiguredService.sharedInstance.configServiceDictionary?.objectForKey(environment) as? NSDictionary
        return serviceDictionaryForEnv?.objectForKey(key) as? String
    }

    class func stringForKeyForAnyEnv(key: String) -> String?
    {
        var returnValue: String? = nil
        if let dictionary = ConfiguredService.sharedInstance.configServiceDictionary
        {
            returnValue = dictionary.valueForKey(key) as? String
        }
        return returnValue
    }
    
    class func sendPaymentURL() -> String?
    {
        var returnURL: String? = nil
        if let baseURL = ConfiguredService.stringForKey("BaseURL")
        {
            returnURL = "\(baseURL)transactions"
        }
        NSLog("Send Payment URL: \(returnURL)")
        return returnURL;
    }

    class func requestPaymentURL() -> String?
    {
        var returnURL: String? = nil
        if let baseURL = ConfiguredService.stringForKey("BaseURL")
        {
            returnURL = "\(baseURL)/transactions"
        }
        NSLog("Request Payment URL: \(returnURL)")
        return returnURL;
    }

    class func transactionHistoryURL(recieverId:String) -> String?
    {
        var returnURL: String? = nil
        if let baseURL = ConfiguredService.stringForKey("BaseURL")
        {
            returnURL = "\(baseURL)transactions?query=\(recieverId)"
        }
        NSLog("Transaction History URL: \(returnURL)")
        return returnURL;
    }

    class func lookupAllAccountsURL() -> String?
    {
        var returnURL: String? = nil
        if let baseURL = ConfiguredService.stringForKey("BaseURL")
        {
            returnURL = "\(baseURL)accounts/lookup"
        }
        NSLog("Accounts Lookup URL: \(returnURL)")
        return returnURL;
    }
    
    class func lookupAccountsURLForGroup(groupName:String) -> String?
    {
        var returnURL: String? = nil
        if let baseURL = ConfiguredService.stringForKey("BaseURL")
        {
            returnURL = "\(baseURL)accounts/lookup?query=\(groupName)"
        }
        NSLog("Accounts Lookup URL: \(returnURL)")
        return returnURL;
    }

    class func contactsGroupName() -> String?
    {
        var groupName: String? = nil
        if let contactsGroupName = ConfiguredService.stringForKey("ContactsGroupName")
        {
            groupName = contactsGroupName
        }
        NSLog("Group Name: \(groupName)")
        return groupName;
    }


}
