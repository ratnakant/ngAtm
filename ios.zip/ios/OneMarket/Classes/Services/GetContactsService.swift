//
//  AccountsLookupService.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/19/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class GetContactsService: BaseService {
   
    var contacts: [Contact]?
    
    func getContactsForGroup(groupName:String, errorHandler:(error:NSError?) -> (), completionHandler:()->())
    {
        var requestUrl = ConfiguredService.lookupAccountsURLForGroup(groupName)
        self.sendRequest(requestUrl, errorHandler:errorHandler, completionHandler:completionHandler)
    }

    override func parseResponseDictionary(dictionary:NSDictionary) -> Bool
    {
        self.contacts = [Contact]()
        
        if let transactions = dictionary["transactions"] as? NSArray
        {
            for transaction in transactions
            {
                if let transactionDict = transaction as? NSDictionary
                {
                    var aContact = Contact()
//                    if let amount = transactionDict["amount"] as? NSNumber
//                    {
//                        let amountInDollars = NSNumber(float:(amount.floatValue/100.0))
//                        aTransaction.amountInCurrency = numberFormatter.stringFromNumber(amountInDollars)
//                    }
//                    aTransaction.memo = transactionDict["memo"] as? String
//                    aTransaction.selectedPhoneOrEmail = transactionDict["receiver_uid"] as? String
//                    if let transactionDate = transactionDict["created"] as? String
//                    {
//                        aTransaction.transactionDate = utcDateFormatter.dateFromString(transactionDate)
//                    }
//                    if let type = transactionDict["type"] as? String
//                    {
//                        if type == "S"
//                        {
//                            aTransaction.type = .Send
//                        }
//                        else if type == "R"
//                        {
//                            aTransaction.type = .Receive
//                        }
//                    }
                    self.contacts?.append(aContact)
                }
            }
        }
        return true
    }
    


}
