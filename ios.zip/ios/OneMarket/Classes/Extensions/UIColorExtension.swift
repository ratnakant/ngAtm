//
//  UIColorExtension.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/12/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

extension UIColor
{
    class func colorWithHexString(hexString:String, alpha:Float=1.0) -> UIColor?
    {
        var hex:NSString = hexString.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet()).uppercaseString
        
        for prefix in ["#", "0X"]
        {
            if (hex.hasPrefix(prefix) == true)
            {
                var length = count(prefix)
                var range = NSMakeRange(length, hex.length-length)
                hex = hex.substringWithRange(range)
            }
        }
        
        if (hex.length < 6)
        {
            return nil;
        }

        var range = NSMakeRange(0, 2);
        var redString = hex.substringWithRange(range)

        range.location = 2;
        var greenString = hex.substringWithRange(range)

        range.location = 4;
        var blueString = hex.substringWithRange(range)

        var red:UInt32 = 0
        var green:UInt32 = 0
        var blue:UInt32 = 0
        
        NSScanner(string:redString).scanHexInt(&red)
        NSScanner(string:greenString).scanHexInt(&green)
        NSScanner(string:blueString).scanHexInt(&blue)

        return UIColor(red:CGFloat(red)/255.0, green:CGFloat(green)/255.0, blue:CGFloat(blue)/255.0, alpha:CGFloat(alpha))
    }
}