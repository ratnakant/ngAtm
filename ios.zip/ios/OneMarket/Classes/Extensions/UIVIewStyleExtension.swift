//
//  UIVIewStyleExtension.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/12/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

extension UIView
{
    func setStyle(styleName:String)
    {
        if let styleDictionary = ConfiguredStyle.sharedInstance.styles
        {
            if let style = styleDictionary[styleName] as? NSDictionary
            {
                if styleName == "VerticalGradientBackground"
                {
                    var colors = [CGColor]()
                    if let bottomColorString = style["bottomColor"] as? String
                    {
                        if let color = UIColor.colorWithHexString(bottomColorString)?.CGColor
                        {
                            colors.append(color)
                        }
                    }
                    if let topColorString = style["topColor"] as? String
                    {
                        if let color = UIColor.colorWithHexString(topColorString)?.CGColor
                        {
                            colors.append(color)
                        }
                    }
                    var gradientLayer = CAGradientLayer()
                    var frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
                    gradientLayer.frame = frame;
                    gradientLayer.colors = colors;
                    self.layer.insertSublayer(gradientLayer, atIndex:0)
                }
            }
        }
    }
    
}