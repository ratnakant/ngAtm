//
//  ContactsManager.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/22/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit
import AddressBook

class ContactManager: NSObject {
    
    var getContactsService:GetContactsService = GetContactsService()
    func downloadContacts(errorHandler:(error:NSError?) -> ())
    {
        if (ABAddressBookGetAuthorizationStatus() == ABAuthorizationStatus.Denied ||
            ABAddressBookGetAuthorizationStatus() == ABAuthorizationStatus.Restricted)
        {
                NSLog("Denied");
        }
        else if (ABAddressBookGetAuthorizationStatus() == ABAuthorizationStatus.Authorized)
        {
            self.addContactsToAddressBook(errorHandler)
        }
        else
        {
            NSLog("Not determined");
        }
    }
    
    func addContactsToAddressBook(errorHandler:(error:NSError?) -> ())
    {
        if let groupName:String = ConfiguredService.contactsGroupName()
        {
            self.getContactsService.getContactsForGroup(groupName, errorHandler: errorHandler) {
                if let contacts = self.getContactsService.contacts
                {
                    if let addressBookRef = ABAddressBookCreateWithOptions(nil, nil)
                    {
                        let addressBook:ABAddressBook = addressBookRef.takeRetainedValue()
                        if let people = ABAddressBookCopyArrayOfAllPeople(addressBook)?.takeRetainedValue() as? NSArray
                        {
                            for existingContact:ABRecordRef in people
                            {
                                var firstName:String?
                                var lastName:String?
                                
                                if let firstName = ABRecordCopyValue(existingContact, kABPersonFirstNameProperty)?.takeRetainedValue() as? String {
                                
                                    if let lastName  = ABRecordCopyValue(existingContact, kABPersonLastNameProperty)?.takeRetainedValue() as? String {
                                        
                                        var contactExists = false
                                        for aContact in contacts
                                        {
                                            if aContact.lastName == lastName && aContact.firstName == firstName
                                            {
                                                contactExists = true
                                                break;
                                            }
                                        }
                                        if  contactExists == false
                                        {
                                            let newContact: ABRecordRef = ABPersonCreate().takeRetainedValue()
                                            ABRecordSetValue(newContact, kABPersonFirstNameProperty, firstName as CFTypeRef, nil)
                                            ABRecordSetValue(newContact, kABPersonLastNameProperty, lastName as CFTypeRef, nil)
                                            
                                            ABAddressBookAddRecord(addressBook, newContact, nil);
                                            ABAddressBookSave(addressBook, nil);
                                        }
                                    }
                                }
                                    
                            }
                        }
                    }
                }
            }
        }
    }
    
    func setupContact(contact:Contact, fromAddressBookRecord  person:ABRecord!)
    {
        var firstName:String?
        var lastName:String?

        if let firstName = ABRecordCopyValue(person, kABPersonFirstNameProperty)?.takeRetainedValue() as? String {
            contact.firstName = firstName
        }
        
        if let lastName  = ABRecordCopyValue(person, kABPersonLastNameProperty)?.takeRetainedValue() as? String {
            contact.lastName = lastName
        }
        
        if let companyName  = ABRecordCopyValue(person, kABPersonOrganizationProperty)?.takeRetainedValue() as? String {
            contact.companyName = companyName
        }
        if let phonesRef = ABRecordCopyValue(person, kABPersonPhoneProperty)
        {
            let phones: ABMultiValueRef = phonesRef.takeRetainedValue()
            contact.phones = [String:String]()
            
            for(var numberIndex : CFIndex = 0; numberIndex < ABMultiValueGetCount(phones); numberIndex++)
            {
                let phoneUnmaganed = ABMultiValueCopyValueAtIndex(phones, numberIndex)
                let phone : String = phoneUnmaganed.takeUnretainedValue() as! String
                
                // Label of Phone Number
                
                let locLabel : CFStringRef = (ABMultiValueCopyLabelAtIndex(phones, numberIndex) != nil) ? ABMultiValueCopyLabelAtIndex(phones, numberIndex).takeUnretainedValue() as CFStringRef : ""
                
                //check for home
                if (String(locLabel) == String(kABHomeLabel))
                {
                    contact.phones?["home"] = phone
                }
                else if (String(locLabel) == String(kABWorkLabel))
                {
                    contact.phones?["work"] = phone
                }
                else if (String(locLabel) == String(kABPersonPhoneMobileLabel))
                {
                    contact.phones?["mobile"] = phone
                }
                else if (String(locLabel) == String(kABPersonPhoneIPhoneLabel))
                {
                    contact.phones?["iPhone"] = phone
                }
                else if(String(locLabel) == String(kABOtherLabel))
                {
                    contact.phones?["other"] = phone
                }
            }
        }
        
        if let emailsRef = ABRecordCopyValue(person,kABPersonEmailProperty)
        {
            let emails: ABMultiValueRef = emailsRef.takeUnretainedValue() as ABMultiValueRef
            
            contact.emails = [String:String]()
            for(var numberIndex : CFIndex = 0; numberIndex < ABMultiValueGetCount(emails); numberIndex++)
            {
                let emailUnmanaged = ABMultiValueCopyValueAtIndex(emails, numberIndex)
                let email : String = emailUnmanaged.takeUnretainedValue() as! String
                
                // Label of Phone Number
                
                let locLabel : CFStringRef = (ABMultiValueCopyLabelAtIndex(emails, numberIndex) != nil) ? ABMultiValueCopyLabelAtIndex(emails, numberIndex).takeUnretainedValue() as CFStringRef : ""
                
                //check for home
                if (String(locLabel) == String(kABHomeLabel))
                {
                    contact.emails?["home"] = email
                }
                else if (String(locLabel) == String(kABWorkLabel))
                {
                    contact.emails?["work"] = email
                }
                else if(String(locLabel) == String(kABOtherLabel))
                {
                    contact.emails?["other"] = email
                }
            }
        }
    }
}
