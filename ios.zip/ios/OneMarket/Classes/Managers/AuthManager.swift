//
//  AuthManager.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/23/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class AuthManager: NSObject {
   
    var authenticatedUser: User?

    class var sharedInstance:AuthManager
    {
        struct Static
        {
            static var instance : AuthManager? = nil
            static var onceToken : dispatch_once_t = 0
        }
        
        dispatch_once(&Static.onceToken)
            {
                Static.instance = AuthManager()
        }
        return Static.instance!
    }
    
    class func isUserSignedIn() -> Bool
    {
        if AuthManager.signedInUser() == nil
        {
            return false
        }
        else
        {
            return true
        }
    }
    
    class func signedInUser() -> User?
    {
        var returnUser: User? = nil
        if let user = AuthManager.sharedInstance.authenticatedUser
        {
            returnUser = user
        }
        else
        {
                returnUser = User.retrieveLastUser()
        }
        return returnUser
    }
    
    class func signout()
    {
        AuthManager.sharedInstance.authenticatedUser = nil
        User.removeLastUser()
    }

}
