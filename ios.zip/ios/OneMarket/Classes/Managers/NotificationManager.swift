//
//  NotificationManager.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/11/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit
import Parse

class NotificationManager: NSObject {
    
    class func registerForRemoteNotifications(application:UIApplication?)
    {
        Parse.setApplicationId("jHrvnycFh0xvN25hRZmC5GBaZgB4Z23hkW7FalNB", clientKey: "GZulmGKLH2BIs1mnC7TAjbwXJIX1moo7Qjum2Xxg")
        var userNotificationTypes:UIUserNotificationType = UIUserNotificationType.Alert | UIUserNotificationType.Badge | UIUserNotificationType.Sound
        var settings = UIUserNotificationSettings(forTypes: userNotificationTypes, categories: nil)
        
        application?.registerUserNotificationSettings(settings)
        application?.registerForRemoteNotifications()
    }
   
    class func setupDeviceToken(deviceTokenData: NSData)
    {
        let installation = PFInstallation.currentInstallation()
        installation.setDeviceTokenFromData(deviceTokenData)
        installation.channels = ["global"]
        installation.saveInBackgroundWithBlock(nil)
    }
    
    class func handleRemoteNotificationWithUserInfo(userInfo:[NSObject : AnyObject])
    {
        PFPush.handlePush(userInfo)
    }
}
