//
//  BaseViewController.swift
//  OneMarket
//
//  Created by Vijay Jain on 5/27/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class BaseViewController: UIViewController {

    func displayError(anError: NSError?)
    {
        if let error = anError
        {
            switch (error.code)
            {
            case 401:
                self.displayAuthenticationError(error)
                
            case 100006, 100003:
                self.displayGenericError(error, title: "Whoops")
                
            case -1001:
                
                let userinfo:[String:String] = ([NSLocalizedDescriptionKey: "Did not get a response from the server. Please try again later.",
                    NSLocalizedFailureReasonErrorKey: "Timed out",
                    NSLocalizedRecoverySuggestionErrorKey: "Try again later"])
                
                let error = NSError(domain: "OneMarket", code: error.code, userInfo: userinfo)
                self.displayServerError(error)
                
            case
            NSURLErrorCannotFindHost,
            NSURLErrorCannotConnectToHost,
            NSURLErrorNotConnectedToInternet,
            NSURLErrorSecureConnectionFailed,
            NSURLErrorServerCertificateHasBadDate,
            NSURLErrorServerCertificateUntrusted,
            NSURLErrorServerCertificateHasUnknownRoot,
            NSURLErrorServerCertificateNotYetValid,
            NSURLErrorClientCertificateRejected,
            NSURLErrorClientCertificateRequired,
            NSURLErrorCannotLoadFromNetwork,
            -1009,
            -1005:
                self.displayNetworkError(error)
                
            case NSURLErrorTimedOut:
                self.displayTimeoutError(error)
                
            default:
                if error.code >= 400
                {
                    self.displayServerError(error)
                }
                else
                {
                    self.displayGenericError(error)
                }
            }
        }
    }
    
    func displayNetworkError(error: NSError)
    {
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            var alertController = UIAlertController(title: "Network Problem", message: error.localizedDescription, preferredStyle: UIAlertControllerStyle.Alert)
            self.addActionsToErrorAlertController(alertController)
            self.presentViewController(alertController, animated: true, completion: nil)
        })
    }
    
    func displayGenericError(error: NSError, title: String = "Error")
    {
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            var alertController = UIAlertController(title: title, message: "\(error.localizedDescription) (Error \(error.code))", preferredStyle: UIAlertControllerStyle.Alert)
            self.addActionsToErrorAlertController(alertController)
            self.presentViewController(alertController, animated: true, completion: nil)
        })
    }
    
    func displayTimeoutError(error: NSError)
    {
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            let errorMessage:String = error.localizedDescription
            var alertController = UIAlertController(title: "Server Error", message: errorMessage, preferredStyle: UIAlertControllerStyle.Alert)
            self.addActionsToErrorAlertController(alertController)
            self.presentViewController(alertController, animated: true, completion: nil)
        })
    }
    
    func displayServerError(error: NSError)
    {
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            let errorMessage: String = error.localizedDescription
            
            var alertController = UIAlertController(title: "Server Error", message: "\(errorMessage) (Error \(error.code))", preferredStyle: UIAlertControllerStyle.Alert)
            self.addActionsToErrorAlertController(alertController)
            
            self.presentViewController(alertController, animated: true, completion: nil)
        })
    }

    func addActionsToErrorAlertController(alertController:UIAlertController)
    {
        var cancelAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Destructive, handler: nil)
        alertController.addAction(cancelAction)
    }

    func displayAuthenticationError(error: NSError)
    {
        let title = "Authentication Error"
        
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            let errorMessage: String = error.localizedDescription
            
            var alertController = UIAlertController(title: title, message: "\(errorMessage) (Error \(error.code))", preferredStyle: UIAlertControllerStyle.Alert)
            self.addActionsToErrorAlertController(alertController)
            
            self.presentViewController(alertController, animated: true, completion: nil)
        })
    }

}
