//
//  SettingsViewController.swift
//  OneMarket
//
//  Created by Jain, Vijay on 6/22/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class SettingsViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Settings"
    }

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        var rowsCount = 1
        return rowsCount
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCellWithIdentifier("SettingTableViewCell", forIndexPath: indexPath) as? UITableViewCell
        
        if (AuthManager.isUserSignedIn())
        {
            cell?.textLabel?.text = "Sign Out"
        }
        else
        {
            cell?.textLabel?.text = "Sign In"
        }
        return cell!
    }

    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        var cell = tableView.cellForRowAtIndexPath(indexPath)
        if (cell?.textLabel?.text == "Sign In")
        {
            var mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
            if let viewController = mainStoryboard.instantiateViewControllerWithIdentifier("SignInViewController") as? SignInViewController
            {
                self.navigationController?.pushViewController(viewController, animated: true)
            }
        }
    }

    @IBAction func cancelButtonTouched(sender:AnyObject?)
    {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
}
