//
//  LoginRegisterViewController.swift
//  OneMarket
//
//  Created by Gloria Flores, Marco on 6/23/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit

class LoginRegisterViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passFirstField: UITextField!
    @IBOutlet weak var passSecondField: UITextField!
    @IBOutlet weak var registerButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        if (count(self.emailField.text) > 0 && count(self.passFirstField.text) > 0 && count(self.passSecondField.text) > 0) {
            textField.resignFirstResponder()
            self.registerButton.enabled = true
        } else {
            if (textField == self.emailField) {
                self.passFirstField.becomeFirstResponder()
            } else {
                if (textField == self.passFirstField) {
                    self.passSecondField.becomeFirstResponder()
                } else {
                    textField.resignFirstResponder()
                }
            }
        }
        return true
    }
    
    @IBAction func registerAction(sender: AnyObject) {
        let userDefaults = NSUserDefaults.standardUserDefaults()
        
        userDefaults.setObject(self.emailField.text, forKey: "user")
        userDefaults.setObject(self.passFirstField.text, forKey: "clave")
        userDefaults.synchronize()
    }

}
