//
//  LoginValidationViewController.swift
//  OneMarket
//
//  Created by Gloria Flores, Marco on 6/17/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit
import LocalAuthentication

class LoginValidationViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var userField: UITextField!
    @IBOutlet weak var passField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    
    var error : NSError?
    var context = LAContext()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        loginButton.enabled = false
        if context.canEvaluatePolicy(LAPolicy.DeviceOwnerAuthenticationWithBiometrics, error: &error) {
            context.evaluatePolicy(LAPolicy.DeviceOwnerAuthenticationWithBiometrics, localizedReason: "Logging in with Touch ID",
                reply: { (success: Bool, error: NSError! ) -> Void in
                    
                    dispatch_async(dispatch_get_main_queue(), {
                        if success {
                            self.performSegueWithIdentifier("dismissLogin", sender: self)
                        }
                        
                        if error != nil {
                            
                            var message: String
                            var showAlert: Bool
                            
                            switch(error.code) {
                            case LAError.AuthenticationFailed.rawValue:
                                message = "There was a problem verifying your identity."
                                showAlert = true
                            case LAError.UserCancel.rawValue:
                                message = "You pressed cancel."
                                showAlert = true
                            case LAError.UserFallback.rawValue:
                                message = "You pressed password."
                                showAlert = true
                            default:
                                showAlert = true
                                message = "Touch ID may not be configured"
                            }
                            
                            var alert = UIAlertView()
                            alert.title = "Error"
                            alert.message = message
                            alert.addButtonWithTitle("Darn!")
                            if showAlert {
                                alert.show()
                            }
                        }
                    })
            })
        } else {
            var alert = UIAlertView()
            alert.title = "Suggestion"
            alert.message = "Touch ID not available, if you enable it, you can use to login to you account"
            alert.addButtonWithTitle("Go it!")
            alert.show()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        if (count(userField.text) > 0 && count(passField.text) > 0) {
            loginButton.enabled = true
        }
        return true 
    }

    @IBAction func performLogin(sender: AnyObject) {
        performSegueWithIdentifier("goToAccounts", sender: self)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
