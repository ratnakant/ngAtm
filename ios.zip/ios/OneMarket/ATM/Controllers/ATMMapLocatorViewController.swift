//
//  ATMMapLocatorViewController.swift
//  OneMarket
//
//  Created by Gloria Flores, Marco on 6/17/15.
//  Copyright (c) 2015 VISA. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class ATMMapLocatorViewController: UIViewController, UISearchBarDelegate, CLLocationManagerDelegate {

    @IBOutlet var mapView: MKMapView!
    @IBOutlet var searchBar: UISearchBar!
    let locationManager = CLLocationManager()
    var items = [MKMapItem]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        startConfiguration()
        self.title = "ATM Locator"
    }
    
    func startConfiguration() {
        searchBar.delegate = self
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }
    
    func locationManager(manager: CLLocationManager!, didUpdateLocations locations: [AnyObject]!) {
        CLGeocoder().reverseGeocodeLocation(manager.location, completionHandler: { (placemarks, error) -> Void in
            if error != nil {
                println("Error in update location:" + error.localizedDescription)
            }
            
            let locationsArray = locations as NSArray
            let location = locationsArray.lastObject as! CLLocation
            
            if (placemarks != nil) {
                let pm = placemarks[0] as! CLPlacemark
                self.displayLocationInfo(pm)
            }
            self.locationManager.stopUpdatingLocation()
            dispatch_async(dispatch_get_main_queue()) {
                self.mapView.setRegion(MKCoordinateRegionMake(CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude), MKCoordinateSpanMake(0.4, 0.4)), animated: true)
                self.makeSearchWithText("ATM near me");
               };
        })
    }
    
    func displayLocationInfo(placemark: CLPlacemark) {
        self.locationManager.stopUpdatingLocation()
    }
    
    func locationManager(manager: CLLocationManager!, didFailWithError error: NSError!) {
        println("Error fail with error:" + error.localizedDescription)
    }
    
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        let nearMe = "ATM near" + searchBar.text
        makeSearchWithText(nearMe);
        searchBar.resignFirstResponder()
    }
    
    func makeSearchWithText(text: String) {
        items.removeAll(keepCapacity: true)
        let request = MKLocalSearchRequest()
        request.naturalLanguageQuery = text
        request.region = mapView.region
        
        let search = MKLocalSearch(request: request)
        
        search.startWithCompletionHandler({(response: MKLocalSearchResponse!,
            error: NSError!) in
            
            if error != nil {
                println("Error occured in search: \(error.localizedDescription)")
            } else if response.mapItems.count == 0 {
                println("No matches found")
            } else {
                if self.mapView.annotations.count > 1 {
                    self.mapView.removeAnnotations(self.mapView.annotations)
                }
                println("Matches found")
                for item in response.mapItems as! [MKMapItem] {
                    self.displayInMap(item)
                    self.items.append(item)
                }
                
            }
        })
        
    }
    
    func displayInMap(mapItem: MKMapItem) {
        var annotation = MKPointAnnotation()
        annotation.coordinate = mapItem.placemark.coordinate
        annotation.title = mapItem.name
        self.mapView.addAnnotation(annotation)
        self.mapView.setRegion(MKCoordinateRegionMake(CLLocationCoordinate2DMake(annotation.coordinate.latitude, annotation.coordinate.longitude), MKCoordinateSpanMake(0.3, 0.3)), animated: true)
        
        
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "List" {
            let tvc = segue.destinationViewController as! ATMListMapLocatorViewController
            if self.items.count > 0 {
                tvc.dataSource = self.items
            }
        }
    }

}
